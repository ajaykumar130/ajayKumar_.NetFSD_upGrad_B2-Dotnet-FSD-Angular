using ContactManagement.API.Data;
using ContactManagement.API.Exceptions;
using ContactManagement.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ContactManagement.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ContactsController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly ILogger<ContactsController> _logger;

    public ContactsController(AppDbContext context, ILogger<ContactsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        return Ok(await _context.Contacts.ToListAsync());
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var contact = await _context.Contacts.FindAsync(id);

        if (contact == null)
            throw new NotFoundException("Contact not found");

        return Ok(contact);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Contact contact)
    {
        if (string.IsNullOrEmpty(contact.Name))
            throw new ValidationException("Name is required");

        _context.Contacts.Add(contact);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Contact created");

        return Ok(contact);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Contact updated)
    {
        var contact = await _context.Contacts.FindAsync(id);

        if (contact == null)
            throw new NotFoundException("Contact not found");

        contact.Name = updated.Name;
        contact.Email = updated.Email;

        await _context.SaveChangesAsync();

        _logger.LogInformation("Contact updated");

        return Ok(contact);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var contact = await _context.Contacts.FindAsync(id);

        if (contact == null)
            throw new NotFoundException("Contact not found");

        _context.Contacts.Remove(contact);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Contact deleted");

        return Ok();
    }
}
