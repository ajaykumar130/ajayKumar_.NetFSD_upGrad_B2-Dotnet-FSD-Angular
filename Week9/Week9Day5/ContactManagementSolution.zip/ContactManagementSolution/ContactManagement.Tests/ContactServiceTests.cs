﻿using NUnit.Framework;
using ContactManagement.Services;
using ContactManagement.Models;
using System.Linq;

namespace ContactManagement.Tests
{
    public class ContactServiceTests
    {
        private ContactService _service;

        [SetUp]
        public void Setup()
        {
            _service = new ContactService();
        }

        [Test]
        public void AddContact_ShouldAddContactSuccessfully()
        {
            var contact = new Contact { Id = 1, Name = "Ajay", Email = "ajay@test.com" };

            _service.AddContact(contact);
            var result = _service.GetAllContacts();

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Count);
        }

        [Test]
        public void GetAllContacts_ShouldReturnNonEmptyList()
        {
            _service.AddContact(new Contact { Id = 1, Name = "A", Email = "a@test.com" });
            _service.AddContact(new Contact { Id = 2, Name = "B", Email = "b@test.com" });

            var result = _service.GetAllContacts();

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count > 0);
        }

        [Test]
        public void GetContactById_ShouldReturnCorrectContact()
        {
            var contact = new Contact { Id = 1, Name = "Ajay", Email = "ajay@test.com" };
            _service.AddContact(contact);

            var result = _service.GetContactById(1);

            Assert.IsNotNull(result);
            Assert.AreEqual("Ajay", result.Name);
        }

        [Test]
        public void DeleteContact_ShouldRemoveContactSuccessfully()
        {
            var contact = new Contact { Id = 1, Name = "Ajay", Email = "ajay@test.com" };
            _service.AddContact(contact);

            var isDeleted = _service.DeleteContact(1);
            var result = _service.GetAllContacts();

            Assert.IsTrue(isDeleted);
            Assert.AreEqual(0, result.Count);
        }

        [Test]
        public void DeleteContact_ShouldReturnFalse_WhenContactNotFound()
        {

            var result = _service.DeleteContact(99);
            Assert.IsFalse(result);
        }
    }
}