﻿using ContactManagement.Models;

namespace ContactManagement.Repositories
{
    public interface IContactRepository
    {
        void Add(Contact contact);
        List<Contact> GetAll();
        bool Delete(int id);
    }
}