using ContactManagement.Models;
using ContactManagement.Repositories;
using ContactManagement.Services;
using Moq;


namespace ContactManagements.Tests
{
    public class ContactServiceTests
    {
        private Mock<IContactRepository> _mockRepo;
        private ContactService _service;

        [SetUp]
        public void Setup()
        {
            _mockRepo = new Mock<IContactRepository>();
            _service = new ContactService(_mockRepo.Object);
        }

        [Test]
        public void AddContact_ShouldCallRepositoryAdd()
        {
            var contact = new Contact { Id = 1, Name = "sai", Email = "sai@test.com" };

            _service.AddContact(contact);

            _mockRepo.Verify(r => r.Add(contact), Times.Once);
        }

        [Test]
        public void GetContacts_ShouldReturnContactsList()
        {
            var contacts = new List<Contact>
            {
                new Contact { Id = 1, Name = "A", Email = "a@test.com" }
            };

            _mockRepo.Setup(r => r.GetAll()).Returns(contacts);

            var result = _service.GetContacts();

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Count);
        }

        [Test]
        public void RemoveContact_ShouldReturnTrue()
        {
            _mockRepo.Setup(r => r.Delete(1)).Returns(true);

            var result = _service.RemoveContact(1);

            Assert.IsTrue(result);
        }

        [Test]
        public void AddContact_ShouldThrowException_WhenContactIsNull()
        {
            Contact contact = null;

            Assert.Throws<System.ArgumentNullException>(() => _service.AddContact(contact));
        }
    }
}